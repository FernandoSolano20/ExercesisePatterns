package bl;

public interface ClienteTemporizador {
    abstract void timeout();
}
