package bl;

public class Puerta {

    void desbloquear(){
        System.out.println("Desbloqueado");
    }

    void bloquear(){
        System.out.println("Bloqueado");
    }
}
