package bl;

public interface ClienteTemporizador {
    String timeout();
}
