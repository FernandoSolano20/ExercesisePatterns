package bl;

public class Puerta {
    String bloquear(){
        return "Bloquear";
    }

    String desbloquear(){
        return "Desbloquear";
    }
}
